"""Metrics and status computation utilities."""
