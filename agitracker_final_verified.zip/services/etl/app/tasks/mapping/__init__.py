"""Mapping tasks for event to signpost linking."""
