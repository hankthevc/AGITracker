"""Analysis tasks for Phase 1."""

from .generate_event_analysis import generate_event_analysis_task

__all__ = ["generate_event_analysis_task"]

